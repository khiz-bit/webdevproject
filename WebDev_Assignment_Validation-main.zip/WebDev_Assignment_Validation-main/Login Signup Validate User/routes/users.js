const express = require('express')
const router = express.Router()
const User = require('../models/user')
const {verifyAccessToken} = require('../helpers/jwtHelper')

router.get('/', verifyAccessToken, async(req,res) => {
    try{
        const users = await User.find()
        res.json(users)
    }catch(err){
        res.send('Error ' + err)
    }
})

router.post('/add', verifyAccessToken, async(req,res) => {
     const user = new User({
        name: req.body.name,
        email: req.body.email
     })

     try{
        const x = await user.save()
        res.json(x)
     }catch(err){
        res.send('Error' + err)
     }
})

//To update a specific field that is pre-defined 
/*router.put('/:id', async(req, res) => {
    try{
        const user = await User.findById(req.params.id)
        user.email = req.body.email
        const x = await user.save()
        res.json(x) 
    }catch(err){
        res.send('Error' + err)
    }
})*/

//To update any field
router.put('/:id', verifyAccessToken, async(req, res, next) => {
        const id = req.params.id
        const updateOps = {}
        for (const ops of req.body){
            updateOps[ops.propName]=ops.value;
        }
        User.update({_id: id}, {$set: updateOps})
        .exec()
        .then(result => {
            console.log(result)
            res.json(result)
        })
        .catch(err => {
            console.log(err)
            res.json({error: err})
        })
})


module.exports = router