const express = require('express')
const mongoose = require('mongoose')
const createError = require('http-errors')
require('dotenv').config()

const {verifyAccessToken} = require('./helpers/jwtHelper')

const url = process.env.MONGODB_URI
const app = express()

mongoose.connect(url, {useNewUrlParser: true})
const conn = mongoose.connection
const PORT = process.env.PORT || 9000

conn.on('open', () => {
    console.log('connected successfully.')
})

app.use(express.json())

app.get('/', verifyAccessToken, async (req, res, next) => {
    
    res.send('Hello from express.')
})

app.use((err, req, res, next) => {
    res.status(err.status || 500)
    res.send({
        error: {
            status: err.status || 500,
            message: err.message,
        },
    })
})

const userRouter = require('./routes/users')
app.use('/users', userRouter)

const authRouter = require('./routes/auth.routes')
app.use('/auth', authRouter)


app.listen(PORT, () => {
    console.log('Server started')
})